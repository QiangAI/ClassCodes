boxplot = df.boxplot(column=['Col1', 'Col2'], by='X',
                     layout=(2, 1))
