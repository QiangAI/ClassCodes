ax = df.plot.bar(x='lifespan', rot=0)
