ax = df.plot.bar(y='speed', rot=0)
