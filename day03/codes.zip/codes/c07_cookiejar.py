# coding = utf-8
import http.cookiejar
import urllib.request
import http.client

host = 'http://www.baidu.com'
request = urllib.request.Request(url=host)
response = urllib.request.urlopen(request)

cookie = http.cookiejar.CookieJar()
# result = cookie.make_cookies(response, request)
cookie.extract_cookies(response,request)

for item in cookie:
    # print(item)
    print(item.name, ':', item.value)

