var DOCUMENTATION_OPTIONS = {
    URL_ROOT: '',
    VERSION: '1.15.1',
    LANGUAGE: 'None',
    COLLAPSE_INDEX: false,
    FILE_SUFFIX: '.html',
    HAS_SOURCE: false,
    SOURCELINK_SUFFIX: '.txt'
};